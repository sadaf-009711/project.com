/**
 * Net Manager ISP - backend (Apps Script Web App, JSON API)
 * Script properties: GEMINI_KEY, SHEET_ID, OWNER_PIN, TECH_PIN (optional)
 * Sheet tabs used: Customers, Bills, Payments, Complaints, TechRequests, Settings (B4 = current month)
 */
const MODEL = 'gemini-2.5-flash';
const CATS = 'Slow speed, No internet, Billing, Router/WiFi, Other';
const TASKS = 'New connection, Repair, Router change, Shifting, Other';

const S = {
  en: {
    pay_need: 'Name or amount not clear. Say it again, e.g. "Ali paid 1000".',
    no_cust: 'Customer not found.',
    pay_ok: '✅ Payment recorded (Rs {a}).',
    name_unclear: 'Customer name not clear. Say it again.',
    req_ok: '✅ {n}: {t} recorded. ID: {id}',
    no_understand: 'I did not understand. Say a payment, balance, report or complaint.',
    ph_nf: 'This number is not in our records.',
    cust_ok: 'Hello {n}, your {t} is recorded. ID: {id}. The technician has been informed.',
    cust_unk: 'Please tell your problem again, e.g. "my internet is slow".',
    latest: 'Your latest request {id} ({c}) is: {s}.',
    latest_none: 'No requests on record.',
    bill_none: 'No bill found for {m}.',
    bill: '{n} ({m})\nTotal: Rs {t}\nPaid: Rs {p}\nPending: Rs {d}\nDue: {due}\nStatus: {i} {s}',
    report: 'Summary {m}\nBilled: Rs {b}\nReceived: Rs {g}\nPending: Rs {p}\n\nNot paid:\n{l}',
    all_paid: 'Everyone has paid 🎉',
    open_hdr: 'Open requests:', open_none: 'No open requests.',
    done_ok: '✅ {id} marked done.', nf: 'Request not found.',
    pin: 'Wrong PIN.', pin_unset: 'OWNER_PIN is not set in Script properties.',
    busy: 'Gemini free limit reached. Wait a minute and try again.',
    Complaint: 'complaint', Technician: 'technician request',
    Paid: 'Paid', Due: 'Due', Overdue: 'Overdue'
  },
  ur: {
    pay_need: 'نام یا رقم واضح نہیں۔ دوبارہ بولیں، جیسے "علی نے 1000 دیے"۔',
    no_cust: 'کسٹمر نہیں ملا۔',
    pay_ok: '✅ ادائیگی درج ہو گئی (Rs {a})۔',
    name_unclear: 'کسٹمر کا نام واضح نہیں۔ دوبارہ بولیں۔',
    req_ok: '✅ {n}: {t} درج ہو گئی۔ آئی ڈی: {id}',
    no_understand: 'سمجھ نہیں آیا۔ ادائیگی، بیلنس، رپورٹ یا شکایت بولیں۔',
    ph_nf: 'یہ نمبر ہمارے ریکارڈ میں نہیں۔',
    cust_ok: 'جی {n}، آپ کی {t} درج ہو گئی۔ آئی ڈی: {id}۔ ٹیکنیشن کو اطلاع کر دی گئی۔',
    cust_unk: 'اپنا مسئلہ دوبارہ بتائیں، جیسے "میرا انٹرنیٹ سلو ہے"۔',
    latest: 'آپ کی آخری درخواست {id} ({c}) کی حالت: {s}۔',
    latest_none: 'کوئی درخواست درج نہیں۔',
    bill_none: '{m} کا بل نہیں ملا۔',
    bill: '{n} ({m})\nکل بل: Rs {t}\nادا: Rs {p}\nباقی: Rs {d}\nآخری تاریخ: {due}\nحالت: {i} {s}',
    report: 'خلاصہ {m}\nبل: Rs {b}\nوصولی: Rs {g}\nباقی: Rs {p}\n\nجنہوں نے ادا نہیں کیا:\n{l}',
    all_paid: 'سب نے ادا کر دیا 🎉',
    open_hdr: 'کھلی درخواستیں:', open_none: 'کوئی درخواست کھلی نہیں۔',
    done_ok: '✅ {id} مکمل ہو گئی۔', nf: 'درخواست نہیں ملی۔',
    pin: 'پن غلط ہے۔', pin_unset: 'OWNER_PIN اسکرپٹ پراپرٹیز میں نہیں۔',
    busy: 'جیمینائی کی مفت حد پوری ہو گئی۔ ایک منٹ بعد دوبارہ کوشش کریں۔',
    Complaint: 'شکایت', Technician: 'ٹیکنیشن کی درخواست',
    Paid: 'ادا شدہ', Due: 'واجب', Overdue: 'مدت گزر گئی',
    st_Open: 'کھلی', st_InProgress: 'جاری', st_Closed: 'بند', st_Pending: 'زیر التوا', st_Assigned: 'مقرر', st_Done: 'مکمل'
  }
};
function t_(l, k, v) {
  let s = S[l === 'ur' ? 'ur' : 'en'][k];
  if (s === undefined) s = S.en[k];
  if (s === undefined) s = k;
  for (const x in (v || {})) s = s.split('{' + x + '}').join(String(v[x]));
  return s;
}

const P = k => PropertiesService.getScriptProperties().getProperty(k);
const sh_ = n => SpreadsheetApp.openById(P('SHEET_ID')).getSheetByName(n);
const rows_ = n => sh_(n).getDataRange().getValues().slice(1);
const tz_ = () => Session.getScriptTimeZone();
const fmt_ = (d, f) => { try { return Utilities.formatDate(new Date(d), tz_(), f); } catch (e) { return ''; } };
const digits_ = s => String(s || '').replace(/\D/g, '').slice(-10);
const month_ = () => sh_('Settings').getRange('B4').getDisplayValue();
const closed_ = s => s === 'Closed' || s === 'Done';

// ---------- Web app entry ----------
function doGet() { return ContentService.createTextOutput('Net Manager API OK'); }
function doPost(e) {
  let out;
  try {
    const r = JSON.parse(e.postData.contents), l = r.lang;
    if (r.action === 'owner') { auth_(r.pin, true, l); out = ownerCommand_(r.text, l); }
    else if (r.action === 'cust') out = custMessage_(r.phone, r.text, l);
    else if (r.action === 'list') { auth_(r.pin, false, l); out = techList_(); }
    else if (r.action === 'done') { auth_(r.pin, false, l); out = techDone_(r.id, l); }
    else throw new Error('Bad action');
    return json_({ ok: true, data: out });
  } catch (err) {
    return json_({ ok: false, error: String(err.message || err) });
  }
}
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function auth_(pin, ownerOnly, l) {
  const o = P('OWNER_PIN'), t = P('TECH_PIN'), p = String(pin || '');
  if (!o) throw new Error(t_(l, 'pin_unset'));
  if (p === o || (!ownerOnly && t && p === t)) return;
  throw new Error(t_(l, 'pin'));
}

// ---------- Data ----------
function customers_() {
  return rows_('Customers').filter(r => r[0]).map(r => ({ id: String(r[0]), name: String(r[1]), phone: String(r[2]), address: String(r[3]) }));
}
function custById_(id) { return customers_().filter(c => c.id === id)[0] || null; }
function custByPhone_(ph) { const d = digits_(ph); return d ? (customers_().filter(c => digits_(c.phone) === d)[0] || null) : null; }

// ---------- Gemini ----------
function gemini_(prompt, text, l) {
  const res = UrlFetchApp.fetch('https://generativelanguage.googleapis.com/v1beta/models/' + (P('GEMINI_MODEL') || MODEL) + ':generateContent', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: { 'x-goog-api-key': P('GEMINI_KEY') },
    payload: JSON.stringify({ contents: [{ parts: [{ text: prompt + '\nUser message: ' + text }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0 } })
  });
  if (res.getResponseCode() === 429) throw new Error(t_(l, 'busy'));
  const b = JSON.parse(res.getContentText());
  if (!b.candidates) throw new Error('Gemini: ' + res.getContentText().slice(0, 150));
  return JSON.parse(b.candidates[0].content.parts[0].text);
}
function ownerPrompt_() {
  const list = customers_().map(c => c.id + ' = ' + c.name).join('\n');
  return 'You are an ISP business manager. Customers (ID = name):\n' + list + '\n\n' +
    'The message is English, Urdu script or Roman Urdu. Names may be in Urdu script: match them to the list. Reply JSON only:\n' +
    '{"intent":"payment|status|report|complaint|technician|open_requests|unknown","customer_id":"C001 or null","amount":number or null,"month":"YYYY-MM or null","method":"Cash|JazzCash|Easypaisa|Bank or null","category":"complaint: one of ' + CATS + '; technician: one of ' + TASKS + '; else null","details":"short English summary","priority":"Low|Medium|High or null"}\n' +
    'payment = someone paid money. status = one customer balance. report = overall summary / who has not paid. complaint = customer problem. technician = send a technician. open_requests = which requests are open.\n' +
    'If name or amount is unclear use null. Never guess.';
}
function customerPrompt_() {
  return 'You are an ISP customer service bot. Message is English, Urdu script or Roman Urdu. Reply JSON only:\n' +
    '{"intent":"complaint|technician|my_bill|request_status|unknown","category":"complaint: one of ' + CATS + '; technician: one of ' + TASKS + '","details":"short English summary","priority":"Low|Medium|High"}\n' +
    'complaint = internet problem. technician = wants a technician visit. my_bill = asks own bill. request_status = asks own complaint status. unknown if unsure.';
}

// ---------- Owner / customer ----------
function ownerCommand_(text, l) {
  const cmd = gemini_(ownerPrompt_(), text, l);
  const month = cmd.month || month_();
  const amt = Number(cmd.amount);
  if (cmd.intent === 'payment') {
    if (!cmd.customer_id || !(amt > 0)) return t_(l, 'pay_need');
    if (!custById_(cmd.customer_id)) return t_(l, 'no_cust');
    addPayment_(cmd.customer_id, month, amt, cmd.method || 'Cash');
    SpreadsheetApp.flush();
    return t_(l, 'pay_ok', { a: amt }) + '\n\n' + statusText_(cmd.customer_id, month, l);
  }
  if (cmd.intent === 'status') return cmd.customer_id ? statusText_(cmd.customer_id, month, l) : t_(l, 'name_unclear');
  if (cmd.intent === 'report') return reportText_(month, l);
  if (cmd.intent === 'open_requests') return openText_(l);
  if (cmd.intent === 'complaint' || cmd.intent === 'technician') {
    const c = cmd.customer_id ? custById_(cmd.customer_id) : null;
    if (!c) return t_(l, 'name_unclear');
    const type = cmd.intent === 'technician' ? 'Technician' : 'Complaint';
    const id = createRequest_(c, type, cmd.category, cmd.details || text, cmd.priority);
    return t_(l, 'req_ok', { n: c.name, t: t_(l, type), id: id });
  }
  return t_(l, 'no_understand');
}
function custMessage_(phone, text, l) {
  const c = custByPhone_(phone);
  if (!c) return t_(l, 'ph_nf');
  const cmd = gemini_(customerPrompt_(), text, l);
  if (cmd.intent === 'complaint' || cmd.intent === 'technician') {
    const type = cmd.intent === 'technician' ? 'Technician' : 'Complaint';
    const id = createRequest_(c, type, cmd.category, cmd.details || text, cmd.priority);
    return t_(l, 'cust_ok', { n: c.name, t: t_(l, type), id: id });
  }
  if (cmd.intent === 'my_bill') return statusText_(c.id, month_(), l);
  if (cmd.intent === 'request_status') return latestText_(c.id, l);
  return t_(l, 'cust_unk');
}

// ---------- Technician ----------
function techList_() {
  const m = {}; customers_().forEach(c => m[c.id] = c);
  const out = [];
  [['Complaints', 'Closed'], ['TechRequests', 'Done']].forEach(x => {
    rows_(x[0]).forEach(r => {
      if (!r[0] || r[7] === x[1]) return;
      const c = m[String(r[2])] || { name: String(r[2]), phone: '', address: '' };
      const comp = x[0] === 'Complaints';
      out.push({ id: String(r[0]), date: fmt_(r[1], 'dd-MMM HH:mm'), name: c.name, phone: c.phone, address: c.address,
        type: comp ? 'Complaint' : 'Technician', cat: String(comp ? r[4] : r[5]), details: comp ? String(r[5]) : '', pri: comp ? String(r[6]) : '' });
    });
  });
  return out;
}
function techDone_(id, l) {
  const tabs = [['Complaints', 'Closed'], ['TechRequests', 'Done']];
  for (let k = 0; k < 2; k++) {
    const sh = sh_(tabs[k][0]), v = sh.getDataRange().getValues();
    for (let i = 1; i < v.length; i++) {
      if (String(v[i][0]) === String(id)) { sh.getRange(i + 1, 8).setValue(tabs[k][1]); return t_(l, 'done_ok', { id: id }); }
    }
  }
  return t_(l, 'nf');
}

// ---------- Writing rows (column D/E hold formulas, so we write cell by cell) ----------
function nextRow_(sh, max) {
  const col = sh.getRange(1, 1, max, 1).getValues();
  let r = 2; while (r <= max && col[r - 1][0] !== '') r++;
  if (r > max) throw new Error(sh.getName() + ' sheet is full');
  return r;
}
function createRequest_(c, type, cat, details, pri) {
  const now = new Date(), tech = type === 'Technician';
  const sh = sh_(tech ? 'TechRequests' : 'Complaints'), r = nextRow_(sh, 300);
  const id = (tech ? 'TR-' : 'CMP-') + fmt_(now, 'ddHHmmss');
  cat = (tech ? TASKS : CATS).split(', ').indexOf(cat) >= 0 ? cat : 'Other';
  sh.getRange(r, 1, 1, 3).setValues([[id, now, c.id]]);
  if (tech) { sh.getRange(r, 6).setValue(cat); sh.getRange(r, 8).setValue('Pending'); }
  else sh.getRange(r, 5, 1, 4).setValues([[cat, details, ['Low', 'Medium', 'High'].indexOf(pri) >= 0 ? pri : 'Medium', 'Open']]);
  return id;
}
function addPayment_(custId, month, amount, method) {
  const sh = sh_('Payments'), r = nextRow_(sh, 500);
  sh.getRange(r, 1, 1, 3).setValues([['P' + fmt_(new Date(), 'yyMMddHHmmss'), new Date(), custId]]);
  sh.getRange(r, 5, 1, 4).setValues([[month, amount, method, 'Web voice']]);
}

// ---------- Text builders ----------
function statusText_(custId, month, l) {
  const b = rows_('Bills').filter(r => String(r[0]) === month && String(r[1]) === custId)[0];
  if (!b) return t_(l, 'bill_none', { m: month });
  const icon = b[12] === 'Paid' ? '🟢' : (b[12] === 'Overdue' ? '🔴' : '🟡');
  return t_(l, 'bill', { n: b[2], m: month, t: b[8], p: b[10], d: b[11], due: fmt_(b[9], 'dd-MMM'), i: icon, s: t_(l, b[12]) });
}
function reportText_(month, l) {
  let bi = 0, got = 0, pe = 0; const lines = [];
  rows_('Bills').filter(r => String(r[0]) === month).forEach(r => {
    bi += Number(r[8]); got += Number(r[10]); pe += Number(r[11]);
    if (r[12] !== 'Paid') lines.push('• ' + r[2] + ': Rs ' + r[11] + ' (' + t_(l, r[12]) + ')');
  });
  return t_(l, 'report', { m: month, b: bi, g: got, p: pe, l: lines.join('\n') || t_(l, 'all_paid') });
}
function reqs_() {
  const a = [];
  rows_('Complaints').forEach(r => r[0] && a.push({ id: String(r[0]), d: new Date(r[1]), cust: String(r[2]), cat: r[4], st: String(r[7]) }));
  rows_('TechRequests').forEach(r => r[0] && a.push({ id: String(r[0]), d: new Date(r[1]), cust: String(r[2]), cat: r[5], st: String(r[7]) }));
  return a;
}
function openText_(l) {
  const m = {}; customers_().forEach(c => m[c.id] = c.name);
  const lines = reqs_().filter(r => !closed_(r.st)).map(r => '• ' + r.id + ': ' + (m[r.cust] || r.cust) + ' - ' + r.cat);
  return lines.length ? t_(l, 'open_hdr') + '\n' + lines.join('\n') : t_(l, 'open_none');
}
function latestText_(custId, l) {
  const a = reqs_().filter(r => r.cust === custId).sort((x, y) => y.d - x.d);
  if (!a.length) return t_(l, 'latest_none');
  const r = a[0];
  return t_(l, 'latest', { id: r.id, c: r.cat, s: t_(l, 'st_' + r.st.replace(/ /g, '')) === 'st_' + r.st.replace(/ /g, '') ? r.st : t_(l, 'st_' + r.st.replace(/ /g, '')) });
}
